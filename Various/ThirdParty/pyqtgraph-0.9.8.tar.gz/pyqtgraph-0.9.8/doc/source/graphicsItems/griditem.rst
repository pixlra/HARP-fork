GridItem
========

.. autoclass:: pyqtgraph.GridItem
    :members:

    .. automethod:: pyqtgraph.GridItem.__init__

