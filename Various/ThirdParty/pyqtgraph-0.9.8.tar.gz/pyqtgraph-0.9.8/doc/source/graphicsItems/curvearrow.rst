CurveArrow
==========

.. autoclass:: pyqtgraph.CurveArrow
    :members:

    .. automethod:: pyqtgraph.CurveArrow.__init__

