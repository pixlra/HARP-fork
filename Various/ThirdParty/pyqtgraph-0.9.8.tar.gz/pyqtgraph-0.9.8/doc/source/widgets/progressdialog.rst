ProgressDialog
==============

.. autoclass:: pyqtgraph.ProgressDialog
    :members:

    .. automethod:: pyqtgraph.ProgressDialog.__init__

