MultiPlotWidget
===============

.. autoclass:: pyqtgraph.MultiPlotWidget
    :members:

    .. automethod:: pyqtgraph.MultiPlotWidget.__init__

