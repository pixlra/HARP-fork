ScatterPlotWidget
=================

.. autoclass:: pyqtgraph.ScatterPlotWidget
    :members:

    .. automethod:: pyqtgraph.ScatterPlotWidget.__init__

