HistogramLUTWidget
==================

.. autoclass:: pyqtgraph.HistogramLUTWidget
    :members:

    .. automethod:: pyqtgraph.HistogramLUTWidget.__init__

