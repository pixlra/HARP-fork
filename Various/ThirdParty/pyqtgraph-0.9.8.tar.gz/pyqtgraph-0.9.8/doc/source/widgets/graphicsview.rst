GraphicsView
============

.. autoclass:: pyqtgraph.GraphicsView
    :members:

    .. automethod:: pyqtgraph.GraphicsView.__init__

