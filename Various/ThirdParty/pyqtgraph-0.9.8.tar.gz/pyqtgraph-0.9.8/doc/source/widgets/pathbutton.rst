PathButton
==========

.. autoclass:: pyqtgraph.PathButton
    :members:

    .. automethod:: pyqtgraph.PathButton.__init__

