MouseClickEvent
===============

.. autoclass:: pyqtgraph.GraphicsScene.mouseEvents.MouseClickEvent
    :members:
